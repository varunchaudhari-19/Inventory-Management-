package com.example.inventory;

import android.app.DatePickerDialog;
import android.content.Context;
import android.widget.EditText;
import android.widget.Toast;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Small helpers shared by all screens. */
public class Ui {
    private static final NumberFormat INR = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));

    public static String money(double v) { return INR.format(v); }

    public static String today() { return daysAgo(0); }

    public static String daysAgo(int n) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -n);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    public static void toast(Context c, String msg) { Toast.makeText(c, msg, Toast.LENGTH_LONG).show(); }

    public static String str(EditText e) { return e.getText().toString().trim(); }

    /** Returns -1 when empty or not a number. */
    public static double num(EditText e) {
        try { return Double.parseDouble(str(e)); } catch (NumberFormatException ex) { return -1; }
    }

    /** Returns -1 when empty or not a whole number. */
    public static int integer(EditText e) {
        try { return Integer.parseInt(str(e)); } catch (NumberFormatException ex) { return -1; }
    }

    /** Tapping the field opens a date picker; the value is stored as yyyy-MM-dd. */
    public static void pickDate(final Context ctx, final EditText et) {
        et.setFocusable(false);
        et.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            try {
                Date parsed = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(str(et));
                if (parsed != null) cal.setTime(parsed);
            } catch (Exception ignored) { }
            new DatePickerDialog(ctx, (picker, y, m, day) ->
                    et.setText(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, day)),
                    cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
        });
    }
}
