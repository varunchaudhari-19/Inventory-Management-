package com.example.inventory;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

/** c. Purchase: receive stock from a supplier. */
public class PurchaseActivity extends AppCompatActivity {
    private DBHelper db;
    private List<DBHelper.Product> products;
    private Spinner spProduct;
    private EditText etQty, etCost, etSupplier, etDate;
    private TextView tvStock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase);
        setTitle("Purchase");
        db = new DBHelper(this);
        spProduct = findViewById(R.id.spProduct);
        etQty = findViewById(R.id.etQty);
        etCost = findViewById(R.id.etCost);
        etSupplier = findViewById(R.id.etSupplier);
        etDate = findViewById(R.id.etDate);
        tvStock = findViewById(R.id.tvStock);

        products = db.getProducts("");
        if (products.isEmpty()) { Ui.toast(this, "Add a product first"); finish(); return; }

        List<String> names = new ArrayList<>();
        for (DBHelper.Product p : products) names.add(p.name + " (" + p.sku + ")");
        spProduct.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));

        long preselect = getIntent().getLongExtra("product_id", -1);
        for (int i = 0; i < products.size(); i++) if (products.get(i).id == preselect) spProduct.setSelection(i);

        spProduct.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                DBHelper.Product p = products.get(pos);
                etCost.setText(String.valueOf(Math.round(p.cost * 100) / 100.0));
                tvStock.setText("Currently in stock: " + p.stock + " " + p.unit);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        etDate.setText(Ui.today());
        Ui.pickDate(this, etDate);
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
    }

    private void save() {
        int qty = Ui.integer(etQty);
        double cost = Ui.num(etCost);
        if (qty <= 0) { Ui.toast(this, "Enter a quantity of 1 or more"); return; }
        if (cost < 0) { Ui.toast(this, "Enter the cost per unit"); return; }
        DBHelper.Product p = products.get(spProduct.getSelectedItemPosition());
        db.addPurchase(p.id, qty, cost, Ui.str(etSupplier), Ui.str(etDate));
        Ui.toast(this, "Purchase saved. Stock is now " + (p.stock + qty) + " " + p.unit);
        finish();
    }
}
