package com.example.inventory;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** f. Profit and loss between two dates. */
public class ProfitLossActivity extends AppCompatActivity {
    private DBHelper db;
    private EditText etFrom, etTo;
    private TextView tvSummary;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        setTitle("Profit & loss");
        db = new DBHelper(this);
        etFrom = findViewById(R.id.etFrom);
        etTo = findViewById(R.id.etTo);
        tvSummary = findViewById(R.id.tvSummary);
        listView = findViewById(R.id.listView);

        etFrom.setText(Ui.daysAgo(30));
        etTo.setText(Ui.today());
        Ui.pickDate(this, etFrom);
        Ui.pickDate(this, etTo);
        findViewById(R.id.btnShow).setOnClickListener(v -> show());
        show();
    }

    private void show() {
        String from = Ui.str(etFrom), to = Ui.str(etTo);
        if (from.compareTo(to) > 0) { Ui.toast(this, "From date cannot be after To date"); return; }

        List<Map<String, String>> rows = new ArrayList<>();
        double[] t = db.getProfitLoss(from, to, rows);
        double net = t[0] - t[1];
        String result = net > 0 ? "PROFIT" : net < 0 ? "LOSS" : "BREAK-EVEN";
        double margin = t[0] == 0 ? 0 : net / t[0] * 100;

        tvSummary.setText("Revenue: " + Ui.money(t[0]) + "\nCost of goods: " + Ui.money(t[1])
                + "\nNet " + result + ": " + Ui.money(Math.abs(net))
                + (t[0] == 0 ? "" : String.format("  (%.1f%% margin)", margin)));
        tvSummary.setTextColor(net > 0 ? Color.parseColor("#157F3B") : net < 0 ? Color.parseColor("#B42318") : Color.BLACK);

        listView.setAdapter(new SimpleAdapter(this, rows, android.R.layout.simple_list_item_2,
                new String[]{"t", "s"}, new int[]{android.R.id.text1, android.R.id.text2}));
    }
}
