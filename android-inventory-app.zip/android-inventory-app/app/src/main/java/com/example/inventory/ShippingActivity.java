package com.example.inventory;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

/** d. Shipping: send goods to a customer and reduce stock. */
public class ShippingActivity extends AppCompatActivity {
    private DBHelper db;
    private List<DBHelper.Product> products = new ArrayList<>();
    private Spinner spProduct;
    private EditText etQty, etPrice, etCustomer, etAddress, etDate;
    private TextView tvStock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipping);
        setTitle("Shipping");
        db = new DBHelper(this);
        spProduct = findViewById(R.id.spProduct);
        etQty = findViewById(R.id.etQty);
        etPrice = findViewById(R.id.etPrice);
        etCustomer = findViewById(R.id.etCustomer);
        etAddress = findViewById(R.id.etAddress);
        etDate = findViewById(R.id.etDate);
        tvStock = findViewById(R.id.tvStock);

        for (DBHelper.Product p : db.getProducts("")) if (p.stock > 0) products.add(p);
        if (products.isEmpty()) { Ui.toast(this, "Nothing in stock to ship. Record a purchase first."); finish(); return; }

        List<String> names = new ArrayList<>();
        for (DBHelper.Product p : products) names.add(p.name + " (" + p.sku + ")");
        spProduct.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));

        long preselect = getIntent().getLongExtra("product_id", -1);
        for (int i = 0; i < products.size(); i++) if (products.get(i).id == preselect) spProduct.setSelection(i);

        spProduct.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                DBHelper.Product p = products.get(pos);
                etPrice.setText(String.valueOf(p.sell));
                tvStock.setText("Available: " + p.stock + " " + p.unit);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        etDate.setText(Ui.today());
        Ui.pickDate(this, etDate);
        findViewById(R.id.btnShip).setOnClickListener(v -> ship());
    }

    private void ship() {
        int qty = Ui.integer(etQty);
        double price = Ui.num(etPrice);
        if (qty <= 0) { Ui.toast(this, "Enter a quantity of 1 or more"); return; }
        if (price < 0) { Ui.toast(this, "Enter the selling price"); return; }
        if (Ui.str(etCustomer).isEmpty()) { Ui.toast(this, "Customer name is required"); return; }

        DBHelper.Product p = products.get(spProduct.getSelectedItemPosition());
        String error = db.addShipment(p.id, qty, price, Ui.str(etCustomer), Ui.str(etAddress), Ui.str(etDate));
        if (error != null) { Ui.toast(this, error); return; }
        Ui.toast(this, "Order shipped. " + (p.stock - qty) + " " + p.unit + " left");
        finish();
    }
}
