package com.example.inventory;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** g. Purchase report from one date to another. */
public class PurchaseReportActivity extends AppCompatActivity {
    private DBHelper db;
    private EditText etFrom, etTo;
    private TextView tvSummary;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        setTitle("Purchase report");
        db = new DBHelper(this);
        etFrom = findViewById(R.id.etFrom);
        etTo = findViewById(R.id.etTo);
        tvSummary = findViewById(R.id.tvSummary);
        listView = findViewById(R.id.listView);

        etFrom.setText(Ui.daysAgo(30));
        etTo.setText(Ui.today());
        Ui.pickDate(this, etFrom);
        Ui.pickDate(this, etTo);
        findViewById(R.id.btnShow).setOnClickListener(v -> show());
        show();
    }

    private void show() {
        String from = Ui.str(etFrom), to = Ui.str(etTo);
        if (from.compareTo(to) > 0) { Ui.toast(this, "From date cannot be after To date"); return; }

        List<Map<String, String>> rows = new ArrayList<>();
        double[] t = db.getPurchaseReport(from, to, rows);
        tvSummary.setText((int) t[0] + " purchase entries  |  " + (int) t[1] + " units\nTotal spent: " + Ui.money(t[2]));

        listView.setAdapter(new SimpleAdapter(this, rows, android.R.layout.simple_list_item_2,
                new String[]{"t", "s"}, new int[]{android.R.id.text1, android.R.id.text2}));
    }
}
