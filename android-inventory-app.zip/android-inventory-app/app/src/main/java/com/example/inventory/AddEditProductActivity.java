package com.example.inventory;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

/** Adds a new product, or edits an existing one when an "id" extra is passed. */
public class AddEditProductActivity extends AppCompatActivity {
    private DBHelper db;
    private long editId = -1;
    private EditText etSku, etName, etCategory, etUnit, etSell, etReorder, etOpening, etCost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_product);
        db = new DBHelper(this);
        etSku = findViewById(R.id.etSku);
        etName = findViewById(R.id.etName);
        etCategory = findViewById(R.id.etCategory);
        etUnit = findViewById(R.id.etUnit);
        etSell = findViewById(R.id.etSell);
        etReorder = findViewById(R.id.etReorder);
        etOpening = findViewById(R.id.etOpening);
        etCost = findViewById(R.id.etCost);

        editId = getIntent().getLongExtra("id", -1);
        DBHelper.Product p = editId == -1 ? null : db.getProduct(editId);
        if (p != null) {
            setTitle("Edit product");
            etSku.setText(p.sku);
            etSku.setEnabled(false);
            etName.setText(p.name);
            etCategory.setText(p.category);
            etUnit.setText(p.unit);
            etSell.setText(String.valueOf(p.sell));
            etReorder.setText(String.valueOf(p.reorder));
            findViewById(R.id.llOpening).setVisibility(View.GONE);
        } else {
            editId = -1;
            setTitle("Add product");
        }
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
    }

    private void save() {
        String sku = Ui.str(etSku), name = Ui.str(etName);
        String cat = Ui.str(etCategory).isEmpty() ? "General" : Ui.str(etCategory);
        String unit = Ui.str(etUnit).isEmpty() ? "pcs" : Ui.str(etUnit);
        double sell = Ui.num(etSell);
        int reorder = Ui.str(etReorder).isEmpty() ? 5 : Ui.integer(etReorder);
        int opening = Ui.str(etOpening).isEmpty() ? 0 : Ui.integer(etOpening);
        double cost = Ui.str(etCost).isEmpty() ? 0 : Ui.num(etCost);

        if (sku.isEmpty() || name.isEmpty()) { Ui.toast(this, "SKU and name are required"); return; }
        if (sell < 0) { Ui.toast(this, "Enter a valid selling price"); return; }
        if (reorder < 0 || opening < 0 || cost < 0) { Ui.toast(this, "Check reorder level, opening stock and cost"); return; }

        if (editId != -1) {
            db.updateProduct(editId, name, cat, unit, sell, reorder);
        } else if (db.addProduct(sku, name, cat, unit, sell, reorder, opening, cost) == -1) {
            Ui.toast(this, "SKU " + sku.toUpperCase() + " already exists");
            return;
        }
        Ui.toast(this, "Product saved");
        finish();
    }
}
