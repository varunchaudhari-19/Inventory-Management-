package com.example.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** All database work: tables, stock rules, and report queries. */
public class DBHelper extends SQLiteOpenHelper {

    public static class Product {
        public long id;
        public String sku, name, category, unit;
        public double cost, sell;      // cost = weighted average cost
        public int stock, reorder;

        public String status() {
            if (stock == 0) return "Out of stock";
            return stock <= reorder ? "Low stock" : "In stock";
        }
    }

    private static final String PRODUCT_COLS =
            "id, sku, name, category, unit, cost_price, sell_price, stock, reorder_level";

    public DBHelper(Context ctx) { super(ctx, "inventory.db", null, 1); }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, sku TEXT NOT NULL UNIQUE,"
                + " name TEXT NOT NULL, category TEXT, unit TEXT, cost_price REAL DEFAULT 0,"
                + " sell_price REAL DEFAULT 0, stock INTEGER DEFAULT 0, reorder_level INTEGER DEFAULT 5)");
        db.execSQL("CREATE TABLE purchases (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL,"
                + " quantity INTEGER NOT NULL, unit_cost REAL NOT NULL, supplier TEXT, date TEXT NOT NULL)");
        db.execSQL("CREATE TABLE shipments (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL,"
                + " quantity INTEGER NOT NULL, unit_price REAL NOT NULL, unit_cost REAL NOT NULL,"
                + " customer TEXT, address TEXT, date TEXT NOT NULL)");
        seed(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) { }

    // ------------------------------------------------------------ core rules
    private long insertProduct(SQLiteDatabase db, String sku, String name, String cat, String unit,
                               double sell, int reorder) {
        ContentValues v = new ContentValues();
        v.put("sku", sku.toUpperCase());
        v.put("name", name);
        v.put("category", cat);
        v.put("unit", unit);
        v.put("sell_price", sell);
        v.put("reorder_level", reorder);
        return db.insert("products", null, v);          // -1 if the SKU already exists
    }

    /** Adds stock and recalculates the weighted-average cost. */
    private void doPurchase(SQLiteDatabase db, long pid, int qty, double unitCost, String supplier, String date) {
        Cursor c = db.rawQuery("SELECT stock, cost_price FROM products WHERE id = ?", new String[]{String.valueOf(pid)});
        if (!c.moveToFirst()) { c.close(); return; }
        int stock = c.getInt(0);
        double avg = c.getDouble(1);
        c.close();

        int newStock = stock + qty;
        double newCost = ((stock * avg) + (qty * unitCost)) / newStock;

        ContentValues p = new ContentValues();
        p.put("product_id", pid);
        p.put("quantity", qty);
        p.put("unit_cost", unitCost);
        p.put("supplier", supplier);
        p.put("date", date);
        db.insert("purchases", null, p);

        ContentValues u = new ContentValues();
        u.put("stock", newStock);
        u.put("cost_price", newCost);
        db.update("products", u, "id = ?", new String[]{String.valueOf(pid)});
    }

    /** Reduces stock and remembers the cost at that moment. Returns an error message or null. */
    private String doShipment(SQLiteDatabase db, long pid, int qty, double unitPrice,
                              String customer, String address, String date) {
        Cursor c = db.rawQuery("SELECT stock, cost_price, name, unit FROM products WHERE id = ?",
                new String[]{String.valueOf(pid)});
        if (!c.moveToFirst()) { c.close(); return "Product not found"; }
        int stock = c.getInt(0);
        double cost = c.getDouble(1);
        String name = c.getString(2), unit = c.getString(3);
        c.close();

        if (qty > stock) return "Only " + stock + " " + unit + " of " + name + " in stock";

        ContentValues s = new ContentValues();
        s.put("product_id", pid);
        s.put("quantity", qty);
        s.put("unit_price", unitPrice);
        s.put("unit_cost", cost);
        s.put("customer", customer);
        s.put("address", address);
        s.put("date", date);
        db.insert("shipments", null, s);

        db.execSQL("UPDATE products SET stock = stock - ? WHERE id = ?", new Object[]{qty, pid});
        return null;
    }

    // ----------------------------------------------------------- public API
    /** Returns the new id, or -1 when the SKU already exists. */
    public long addProduct(String sku, String name, String cat, String unit, double sell, int reorder,
                           int openingStock, double cost) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long id = insertProduct(db, sku, name, cat, unit, sell, reorder);
            if (id == -1) return -1;
            if (openingStock > 0) doPurchase(db, id, openingStock, cost, "Opening stock", Ui.today());
            db.setTransactionSuccessful();
            return id;
        } finally {
            db.endTransaction();
        }
    }

    public void updateProduct(long id, String name, String cat, String unit, double sell, int reorder) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("category", cat);
        v.put("unit", unit);
        v.put("sell_price", sell);
        v.put("reorder_level", reorder);
        getWritableDatabase().update("products", v, "id = ?", new String[]{String.valueOf(id)});
    }

    public void addPurchase(long pid, int qty, double unitCost, String supplier, String date) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            doPurchase(db, pid, qty, unitCost, supplier, date);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public String addShipment(long pid, int qty, double unitPrice, String customer, String address, String date) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            String err = doShipment(db, pid, qty, unitPrice, customer, address, date);
            if (err == null) db.setTransactionSuccessful();
            return err;
        } finally {
            db.endTransaction();
        }
    }

    private Product readProduct(Cursor c) {
        Product p = new Product();
        p.id = c.getLong(0);
        p.sku = c.getString(1);
        p.name = c.getString(2);
        p.category = c.getString(3);
        p.unit = c.getString(4);
        p.cost = c.getDouble(5);
        p.sell = c.getDouble(6);
        p.stock = c.getInt(7);
        p.reorder = c.getInt(8);
        return p;
    }

    /** a. List of all products (optionally filtered by name, SKU or category). */
    public List<Product> getProducts(String query) {
        String like = "%" + query + "%";
        Cursor c = getReadableDatabase().rawQuery("SELECT " + PRODUCT_COLS
                + " FROM products WHERE name LIKE ? OR sku LIKE ? OR category LIKE ? ORDER BY name",
                new String[]{like, like, like});
        List<Product> list = new ArrayList<>();
        while (c.moveToNext()) list.add(readProduct(c));
        c.close();
        return list;
    }

    /** b. One product's information. */
    public Product getProduct(long id) {
        Cursor c = getReadableDatabase().rawQuery("SELECT " + PRODUCT_COLS + " FROM products WHERE id = ?",
                new String[]{String.valueOf(id)});
        Product p = c.moveToFirst() ? readProduct(c) : null;
        c.close();
        return p;
    }

    public List<String> purchaseHistory(long pid) {
        Cursor c = getReadableDatabase().rawQuery("SELECT date, quantity, unit_cost, supplier FROM purchases"
                + " WHERE product_id = ? ORDER BY date DESC, id DESC", new String[]{String.valueOf(pid)});
        List<String> out = new ArrayList<>();
        while (c.moveToNext()) {
            String sup = c.getString(3);
            out.add(c.getString(0) + "   +" + c.getInt(1) + " @ " + Ui.money(c.getDouble(2))
                    + (sup == null || sup.isEmpty() ? "" : "   (" + sup + ")"));
        }
        c.close();
        return out;
    }

    public List<String> shipmentHistory(long pid) {
        Cursor c = getReadableDatabase().rawQuery("SELECT date, quantity, unit_price, customer FROM shipments"
                + " WHERE product_id = ? ORDER BY date DESC, id DESC", new String[]{String.valueOf(pid)});
        List<String> out = new ArrayList<>();
        while (c.moveToNext()) {
            out.add(c.getString(0) + "   -" + c.getInt(1) + " @ " + Ui.money(c.getDouble(2))
                    + "   (" + c.getString(3) + ")");
        }
        c.close();
        return out;
    }

    private static Map<String, String> row(String title, String sub) {
        Map<String, String> m = new HashMap<>();
        m.put("t", title);
        m.put("s", sub);
        return m;
    }

    /** e. Balance stock. Fills rows; returns {products, units on hand, stock value}. */
    public double[] getStockBalance(List<Map<String, String>> out) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT p.name, p.sku, p.unit, p.stock, p.cost_price, p.reorder_level,"
                        + " (SELECT IFNULL(SUM(quantity),0) FROM purchases WHERE product_id = p.id),"
                        + " (SELECT IFNULL(SUM(quantity),0) FROM shipments WHERE product_id = p.id)"
                        + " FROM products p ORDER BY p.name", null);
        int products = 0, units = 0;
        double value = 0;
        while (c.moveToNext()) {
            int stock = c.getInt(3);
            double cost = c.getDouble(4);
            String status = stock == 0 ? "OUT OF STOCK" : stock <= c.getInt(5) ? "LOW STOCK" : "In stock";
            out.add(row(c.getString(0) + "  (" + c.getString(1) + ")",
                    "Purchased " + c.getInt(6) + "  |  Shipped " + c.getInt(7) + "  |  Balance " + stock
                            + " " + c.getString(2) + "\nValue " + Ui.money(stock * cost) + "  |  " + status));
            products++;
            units += stock;
            value += stock * cost;
        }
        c.close();
        return new double[]{products, units, value};
    }

    /** f. Profit and loss between two dates. Fills rows; returns {revenue, cost}. */
    public double[] getProfitLoss(String from, String to, List<Map<String, String>> out) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT p.name, p.sku, SUM(s.quantity), SUM(s.quantity * s.unit_price), SUM(s.quantity * s.unit_cost)"
                        + " FROM shipments s JOIN products p ON p.id = s.product_id"
                        + " WHERE s.date BETWEEN ? AND ? GROUP BY p.id"
                        + " ORDER BY (SUM(s.quantity * s.unit_price) - SUM(s.quantity * s.unit_cost)) DESC",
                new String[]{from, to});
        double revenue = 0, cost = 0;
        while (c.moveToNext()) {
            double rev = c.getDouble(3), cst = c.getDouble(4), net = rev - cst;
            out.add(row(c.getString(0) + "  (" + c.getString(1) + ")",
                    "Sold " + c.getInt(2) + "  |  Revenue " + Ui.money(rev) + "  |  Cost " + Ui.money(cst)
                            + "\n" + (net >= 0 ? "Profit " : "Loss ") + Ui.money(Math.abs(net))));
            revenue += rev;
            cost += cst;
        }
        c.close();
        return new double[]{revenue, cost};
    }

    /** g. Purchase report between two dates. Fills rows; returns {entries, units, amount}. */
    public double[] getPurchaseReport(String from, String to, List<Map<String, String>> out) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT pu.date, p.name, p.sku, pu.supplier, pu.quantity, pu.unit_cost"
                        + " FROM purchases pu JOIN products p ON p.id = pu.product_id"
                        + " WHERE pu.date BETWEEN ? AND ? ORDER BY pu.date DESC, pu.id DESC",
                new String[]{from, to});
        int units = 0;
        double amount = 0;
        while (c.moveToNext()) {
            int qty = c.getInt(4);
            double cost = c.getDouble(5);
            String sup = c.getString(3);
            out.add(row(c.getString(0) + "  -  " + c.getString(1) + "  (" + c.getString(2) + ")",
                    "Qty " + qty + " @ " + Ui.money(cost) + " = " + Ui.money(qty * cost)
                            + (sup == null || sup.isEmpty() ? "" : "\nSupplier: " + sup)));
            units += qty;
            amount += qty * cost;
        }
        int entries = out.size();
        c.close();
        return new double[]{entries, units, amount};
    }

    // ------------------------------------------------------------ sample data
    private void seed(SQLiteDatabase db) {
        String[][] items = {
                {"LAP-001", "Laptop 14\" i5", "Computers", "52000", "3"},
                {"MOU-002", "Wireless Mouse", "Accessories", "650", "10"},
                {"KEY-003", "Mechanical Keyboard", "Accessories", "2400", "5"},
                {"MON-004", "24\" LED Monitor", "Computers", "9800", "4"},
                {"USB-005", "USB-C Cable 1m", "Accessories", "220", "20"},
                {"PRN-006", "Laser Printer", "Office", "14500", "2"}};
        long[] ids = new long[items.length];
        for (int i = 0; i < items.length; i++) {
            ids[i] = insertProduct(db, items[i][0], items[i][1], items[i][2], "pcs",
                    Double.parseDouble(items[i][3]), Integer.parseInt(items[i][4]));
        }
        // product index, qty, unit cost, supplier, days ago
        Object[][] buys = {
                {0, 10, 45000.0, "Dell Distributors", 40}, {1, 60, 480.0, "Logi Wholesale", 38},
                {2, 25, 1700.0, "KeyCraft Pvt Ltd", 35}, {3, 12, 8200.0, "Dell Distributors", 30},
                {4, 150, 140.0, "Cable World", 28}, {5, 6, 12000.0, "HP Supplies", 25},
                {0, 5, 47000.0, "Dell Distributors", 12}, {1, 40, 520.0, "Logi Wholesale", 9}};
        for (Object[] b : buys) {
            doPurchase(db, ids[(Integer) b[0]], (Integer) b[1], (Double) b[2], (String) b[3], Ui.daysAgo((Integer) b[4]));
        }
        // product index, qty, unit price, customer, city, days ago
        Object[][] sells = {
                {0, 4, 54000.0, "Sharma Traders", "Pune", 20}, {1, 25, 700.0, "Gupta Stores", "Mumbai", 18},
                {2, 8, 2600.0, "Tech Hub", "Nashik", 15}, {3, 5, 10500.0, "Office Mart", "Pune", 14},
                {4, 140, 200.0, "Cable Depot", "Nagpur", 10}, {5, 5, 14000.0, "Print Point", "Thane", 7},
                {0, 3, 55500.0, "Kiran Computers", "Satara", 3}, {1, 30, 690.0, "Gupta Stores", "Mumbai", 2}};
        for (Object[] s : sells) {
            doShipment(db, ids[(Integer) s[0]], (Integer) s[1], (Double) s[2], (String) s[3], (String) s[4],
                    Ui.daysAgo((Integer) s[5]));
        }
    }
}
