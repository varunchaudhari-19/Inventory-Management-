package com.example.inventory;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** a. List of all products. Tap one to see its details. */
public class ProductListActivity extends AppCompatActivity {
    private DBHelper db;
    private EditText etSearch;
    private ListView listView;
    private List<DBHelper.Product> products = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);
        setTitle("Products");
        db = new DBHelper(this);
        etSearch = findViewById(R.id.etSearch);
        listView = findViewById(R.id.lvProducts);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { load(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        findViewById(R.id.btnAdd).setOnClickListener(v ->
                startActivity(new Intent(this, AddEditProductActivity.class)));
        listView.setOnItemClickListener((parent, view, pos, id) -> {
            Intent i = new Intent(this, ProductDetailActivity.class);
            i.putExtra("id", products.get(pos).id);
            startActivity(i);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        products = db.getProducts(etSearch.getText().toString().trim());
        List<Map<String, String>> rows = new ArrayList<>();
        for (DBHelper.Product p : products) {
            Map<String, String> m = new HashMap<>();
            m.put("t", p.name + "  (" + p.sku + ")");
            m.put("s", p.category + "  |  " + p.stock + " " + p.unit + "  |  Sell " + Ui.money(p.sell)
                    + "\n" + p.status());
            rows.add(m);
        }
        listView.setAdapter(new SimpleAdapter(this, rows, android.R.layout.simple_list_item_2,
                new String[]{"t", "s"}, new int[]{android.R.id.text1, android.R.id.text2}));
    }
}
