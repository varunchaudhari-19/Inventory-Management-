package com.example.inventory;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** e. Balance stock = total purchased - total shipped. */
public class StockBalanceActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        setTitle("Stock balance");
    }

    @Override
    protected void onResume() {
        super.onResume();
        List<Map<String, String>> rows = new ArrayList<>();
        double[] t = new DBHelper(this).getStockBalance(rows);
        ((TextView) findViewById(R.id.tvSummary)).setText(
                (int) t[0] + " products  |  " + (int) t[1] + " units on hand\nTotal stock value: " + Ui.money(t[2]));
        ((ListView) findViewById(R.id.listView)).setAdapter(new SimpleAdapter(this, rows,
                android.R.layout.simple_list_item_2, new String[]{"t", "s"},
                new int[]{android.R.id.text1, android.R.id.text2}));
    }
}
