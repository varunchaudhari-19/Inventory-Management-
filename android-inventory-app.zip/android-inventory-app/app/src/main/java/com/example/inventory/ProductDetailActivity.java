package com.example.inventory;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

/** b. Individual product information with purchase and shipment history. */
public class ProductDetailActivity extends AppCompatActivity {
    private DBHelper db;
    private long productId;
    private TextView tvName, tvInfo, tvHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        setTitle("Product details");
        db = new DBHelper(this);
        productId = getIntent().getLongExtra("id", -1);
        tvName = findViewById(R.id.tvName);
        tvInfo = findViewById(R.id.tvInfo);
        tvHistory = findViewById(R.id.tvHistory);

        findViewById(R.id.btnEdit).setOnClickListener(v -> start(AddEditProductActivity.class, "id"));
        findViewById(R.id.btnBuy).setOnClickListener(v -> start(PurchaseActivity.class, "product_id"));
        findViewById(R.id.btnShip).setOnClickListener(v -> start(ShippingActivity.class, "product_id"));
    }

    private void start(Class<?> target, String extra) {
        Intent i = new Intent(this, target);
        i.putExtra(extra, productId);
        startActivity(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        DBHelper.Product p = db.getProduct(productId);
        if (p == null) { finish(); return; }

        tvName.setText(p.name);
        tvInfo.setText("SKU: " + p.sku
                + "\nCategory: " + p.category
                + "\nStatus: " + p.status()
                + "\nCurrent stock: " + p.stock + " " + p.unit
                + "\nReorder level: " + p.reorder
                + "\nSelling price: " + Ui.money(p.sell)
                + "\nAverage cost: " + Ui.money(p.cost)
                + "\nStock value: " + Ui.money(p.stock * p.cost));

        StringBuilder sb = new StringBuilder("PURCHASE HISTORY\n");
        append(sb, db.purchaseHistory(productId), "No purchases yet.");
        sb.append("\nSHIPMENT HISTORY\n");
        append(sb, db.shipmentHistory(productId), "No shipments yet.");
        tvHistory.setText(sb.toString());
    }

    private void append(StringBuilder sb, List<String> lines, String empty) {
        if (lines.isEmpty()) sb.append(empty).append('\n');
        for (String s : lines) sb.append(s).append('\n');
    }
}
