package com.example.inventory;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private TextView tvSummary;
    private DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DBHelper(this);
        tvSummary = findViewById(R.id.tvSummary);

        open(R.id.btnProducts, ProductListActivity.class);
        open(R.id.btnPurchase, PurchaseActivity.class);
        open(R.id.btnShipping, ShippingActivity.class);
        open(R.id.btnBalance, StockBalanceActivity.class);
        open(R.id.btnProfit, ProfitLossActivity.class);
        open(R.id.btnReport, PurchaseReportActivity.class);
    }

    private void open(int buttonId, Class<?> target) {
        findViewById(buttonId).setOnClickListener(v -> startActivity(new Intent(this, target)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        double[] t = db.getStockBalance(new ArrayList<>());
        tvSummary.setText((int) t[0] + " products  |  " + (int) t[1] + " units in stock\nStock value: " + Ui.money(t[2]));
    }
}
