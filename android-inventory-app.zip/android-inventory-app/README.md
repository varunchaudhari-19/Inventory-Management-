# StockRoom – Android Inventory App (Java + XML)

Works fully offline. Data is stored in an on-device SQLite database. Sample data is added on first launch.

## Set up in Android Studio
1. File > New > New Project > "Empty Views Activity".
   Name: StockRoom, Package name: com.example.inventory, Language: Java, Minimum SDK: API 24.
2. Delete the generated MainActivity.java and res/layout/activity_main.xml.
3. Copy this project's files over the new project's files, keeping the same folders:
   - app/src/main/java/com/example/inventory/*.java
   - app/src/main/res/layout/*.xml
   - app/src/main/res/values/themes.xml  (replaces the existing one)
   - app/src/main/AndroidManifest.xml    (replaces the existing one)
4. Sync Gradle, then Run on an emulator or phone.

If you see a "Theme.Inventory not found" style error, delete app/src/main/res/values-night/themes.xml.
To reset the data, uninstall the app (or Clear storage in App info).
